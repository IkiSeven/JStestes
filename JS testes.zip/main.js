var form = document.getElementById("formMain");

form.addEventListener("submit", function(e){
  e.preventDefault();
  var email = document.getElementById("formEmail");
  var senha = document.getElementById("formPass");
  
  if (email == "tadeu@mail.com" && senha == "argila") {
    alert("logado com sucesso!")
  }
  else {
    alert("Algo deu errado! tente novamente!");
  }
});